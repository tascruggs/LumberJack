package main;

public class Lumber {

	double width;
	double height;
	double length;
	double value;
	double quantity;

	//Constructor
	public Lumber(double w, double h, double l, double v, double q){
		width = w;
		height = h;
		length = l;
		value = v;
		quantity = q;
	}
}
